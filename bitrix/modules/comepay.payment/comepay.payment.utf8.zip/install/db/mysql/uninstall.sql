DROP TABLE if exists comepay_payment;
