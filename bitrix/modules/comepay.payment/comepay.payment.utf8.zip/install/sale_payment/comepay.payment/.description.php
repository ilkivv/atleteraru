<?
require($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/comepay.payment/payment/comepay.payment/.description.php");
?>