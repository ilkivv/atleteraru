<?
require_once(dirname(__FILE__)."/../modules/comepay.payment/tools/notify.php");
?>