<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $MESS;
$MESS['COMEPAY.PAYMENT_ORDER_DESCRIPTION'] = "Заказ полностью оплачен. #PAYER#.";
$MESS['COMEPAY.PAYMENT_STATUS_PAID'] = "Счёт оплачен";
$MESS['COMEPAY.PAYMENT_STATUS_WAITING'] = "Счёт выставлен, ожидает оплаты";
$MESS['COMEPAY.PAYMENT_STATUS_REJECTED'] = "Счёт отклонен";
$MESS['COMEPAY.PAYMENT_STATUS_UNPAID'] = "Ошибка при проведении оплаты. Счёт не оплачен";
$MESS['COMEPAY.PAYMENT_STATUS_EXPIRED'] = "Время жизни счёта истекло. Счёт не оплачен";
$MESS['COMEPAY.PAYMENT_ORDER_PART_PAYMENT'] = "Частичная оплата заказа на сумму #SUM#";