<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $MESS;
$MESS['COMEPAY.PAYMENT_LEFT_TO_PAY'] = "Спасибо, за оплату счёта. Для полной оплаты заказа Вам осталось оплатить счета на сумму #SUM# рублей.";
$MESS['COMEPAY.PAYMENT_SUCCESS_PAYMENT'] = "Спасибо за оплату заказа. Статус оплаты заказа в скором времени обновится автоматически";
$MESS['COMEPAY.PAYMENT_GOTO_ORDER'] = "Перейти на станицу заказа";
$MESS['COMEPAY.PAYMENT_ORDER_NOT_FOUND'] = "Ошибка! Заказ не найден";