<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $MESS;
$MESS['COMEPAY.PAYMENT_SOME_ERROR'] = "При оплате счёта произошла ошибка";
$MESS['COMEPAY.PAYMENT_GOTO_ORDER'] = "Перейти на станицу заказа";
$MESS['COMEPAY.PAYMENT_ORDER_NOT_FOUND'] = "Ошибка! Заказ не найден";