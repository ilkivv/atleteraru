<?
global $MESS;
$MESS ['COMEPAY.PAYMENT_ORDER_COMMENT_PART'] = "Оплата заказа №#ID#";

?>