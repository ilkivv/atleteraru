<?
global $MESS;
$MESS ['COMEPAY.PAYMENT_PARTNER_NAME'] = "ООО \"Кампэй\"";
$MESS ['COMEPAY.PAYMENT_INSTALL_NAME'] = "Comepay оплата";
$MESS ['COMEPAY.PAYMENT_INSTALL_DESCRIPTION'] = "Приём оплаты через Comepay.";
$MESS ['COMEPAY.PAYMENT_INSTALL_TITLE'] = "Установка модуля платёжных сервисов";
$MESS ['COMEPAY.PAYMENT_INSTALL_PUBLIC_DIR'] = "Публичная папка";
$MESS ['COMEPAY.PAYMENT_INSTALL_SETUP'] = "Установить";
$MESS ['COMEPAY.PAYMENT_INSTALL_COMPLETE_OK'] = "Установка завершена. Для дополнительной помощи обратитесь в раздел помощи.";
$MESS ['COMEPAY.PAYMENT_INSTALL_COMPLETE_ERROR'] = "Установка завершена с ошибками";
$MESS ['COMEPAY.PAYMENT_INSTALL_ERROR'] = "Ошибки при установке";
$MESS ['COMEPAY.PAYMENT_INSTALL_BACK'] = "Вернуться в управление модулями";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_WARNING'] = "Внимание! Модуль будет удален из системы.";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_SAVEDATA'] = "Вы можете сохранить данные в таблицах базы данных, если установите флажок &quot;Сохранить таблицы&quot;";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_SAVETABLE'] = "Сохранить таблицы";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_DEL'] = "Удалить";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_ERROR'] = "Ошибки при удалении:";
$MESS ['COMEPAY.PAYMENT_UNINSTALL_COMPLETE'] = "Удаление завершено.";
$MESS ['COMEPAY.PAYMENT_INSTALL_PUBLIC_SETUP'] = "Установить";
$MESS ['COMEPAY.PAYMENT_INSTALL_UNPOSSIBLE'] = "Деинсталляция модуля невозможна.";
?>