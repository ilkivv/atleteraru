<?
define("ADMIN_MODULE_NAME", "comepay.payment");
?>