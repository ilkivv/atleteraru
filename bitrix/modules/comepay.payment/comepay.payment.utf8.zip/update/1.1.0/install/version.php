<?
$arModuleVersion = array(
	"VERSION" => "1.1.0",
	"VERSION_DATE" => "2015-08-25 15:00:00"
);
?>