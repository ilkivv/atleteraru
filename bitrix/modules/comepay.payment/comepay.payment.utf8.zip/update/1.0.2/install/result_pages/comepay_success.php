<?
require_once(dirname(__FILE__)."/bitrix/modules/comepay.payment/tools/success.php");
?>