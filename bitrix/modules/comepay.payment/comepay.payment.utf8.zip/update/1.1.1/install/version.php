<?
$arModuleVersion = array(
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2015-10-20 15:00:00"
);
?>